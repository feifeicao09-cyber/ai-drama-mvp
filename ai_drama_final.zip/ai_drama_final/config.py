from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
CHARACTER_DIR = DATA_DIR / "characters"
GENERATED_DIR = ROOT / "assets" / "generated"
AUDIO_DIR = ROOT / "assets" / "audio"
SUBTITLE_DIR = ROOT / "assets" / "subtitles"
OUTPUT_DIR = ROOT / "output"
PROJECT_PATH = DATA_DIR / "project.json"
